<?
session_start();
session_destroy();
?>
<form action="login.html">
	<input type="submit" value="Вход">
</form>
<form action="index.html">
	<input type="submit" value="Главная">
</form>
